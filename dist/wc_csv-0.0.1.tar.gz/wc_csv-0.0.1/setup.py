from setuptools import setup

setup(
    name = "wc_csv",
    version = "0.0.1",
    packages=['wc_csv'],
)
